export type Event = {
  id: number;
  name: string;
  start: string;
  end: string;
  startDate: Date;
  endDate: Date;
};
